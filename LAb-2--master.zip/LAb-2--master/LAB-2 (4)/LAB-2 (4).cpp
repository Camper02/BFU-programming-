﻿// LAB-2 (4).cpp: определяет точку входа для приложения.
//

#include "LAB-2 (4).h"

using namespace std;

int main()
{
	cout << "Hello CMake." << endl;
	return 0;
}
