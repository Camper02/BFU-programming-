﻿#include <iostream>
using namespace std;

class Smart_arr
{
public:
	int l = 0;
	int* arr = new int;


	void add(int num) //добавление элемента
	{
		int* arr1 = new int[l + 1];
		for (int i = 0; i < l; i++)
		{
			arr1[i] = arr[i];
		}
		arr1[l] = num;
		l++;
		delete[] arr;
		arr = arr1;
	}

	void out_l() //вывод
	{
		cout << "Текущая длина: " << l << endl;
	}

	void out_elem(int i) //вывод
	{
		cout << "Элемент под индексом " << i << " - " << arr[i] << endl;
	}

	void replace_elem(int i, int new_elem) //замена элемента
	{
		arr[i] = new_elem;
	}

	void delete_elem(int i) // удаление элемента
	{
		int* arr1 = new int[l - 1];
		int f = 0;
		for (int j = 0; j < l; j++)
		{
			if (j == i)
			{
				f++;
				continue;
			}
			arr1[j - f] = arr[j];
		}
		delete arr;
		l -= 1;
		arr = arr1;
	}

	void insert_elem(int num, int i) // вставить элемент по индексу
	{
		int* arr1 = new int[l + 1];
		int f = 0;
		for (int j = 0; j < l + 1; j++)
		{
			if (j == i)
			{
				f++;
				arr1[i] = num;
			}
			else
			{
				arr1[j] = arr[j - f];
			}

		}
		delete arr;
		l++;
		arr = arr1;
	}

};

int main()
{
	setlocale(LC_ALL, "Russian");
	Smart_arr array;
	int index_a, index_b;

	cout << "Управление:\n0 - выход\n1 - добавить элемент\n2 - вывести длину\n3 - вывести элемент по индексу\n4 - заменить элемент по индексу\n5 - удалить элемент по индексу\n6 - вставить элемент по индексу" << endl;
	while (true)
	{
		cin >> index_a;
		if (index_a == 0)
		{
			break;
		}
		else
		{
			if (index_a == 1)
			{
				cout << "Введите элемент:";
				cin >> index_a;
				array.add(index_a);
			}
			else
			{
				if (index_a == 2)
				{
					array.out_l();
				}
				else
				{
					if (index_a == 3)
					{
						if (array.l > 0)
						{
							cout << "Введите индекс:";
							cin >> index_a;
							if (array.l > index_a)
							{
								array.out_elem(index_a);
							}

						}
					}
					else
					{
						if (index_a == 4)
						{
							cout << "Введите элемент на который хотите заменить:";
							cin >> index_a;
							cout << "Введите индекс заменяемого:";
							cin >> index_b;
							array.replace_elem(index_a, index_b);
						}
						else
						{
							if (index_a == 5)
							{
								if (array.l > 0)
								{
									cout << "Введите индекс:";
									cin >> index_a;
									if (array.l > index_a)
									{
										array.delete_elem(index_a);
									}
								}
							}
							else
							{
								if (index_a == 6)
								{
									cout << "Введите вставляемый элемент:";
									cin >> index_a;
									cout << "Введите индекс:";
									cin >> index_b;
									array.insert_elem(index_a, index_b);
								}
							}
						}
					}
				}
			}
		}
	}
}